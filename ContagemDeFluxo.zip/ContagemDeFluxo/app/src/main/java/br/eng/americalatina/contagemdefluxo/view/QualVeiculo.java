package br.eng.americalatina.contagemdefluxo.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

import br.eng.americalatina.contagemdefluxo.R;
import br.eng.americalatina.contagemdefluxo.api.AppUtil;
import br.eng.americalatina.contagemdefluxo.model.FluxoVeiculo;
import br.eng.americalatina.contagemdefluxo.model.Veiculo;

public class QualVeiculo extends AppCompatActivity {
    private SharedPreferences preferences;
    List<Veiculo> veiculos;
    FluxoVeiculo fluxo;
    Veiculo veiculo;
    Button btnReturn, btnCarro, btnMoto, btnUtilitario, btnOnibus, btnCaminhao, btnCarreta, btnReboque;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qual_veiculo);
        initFormulario();

        restaurarSharedPreferences();


        btnCarro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veiculo.setTipo("Carro");
                goToMain();
            }
        });
        btnMoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veiculo.setTipo("Moto");
                goToMain();
            }
        });
        btnUtilitario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veiculo.setTipo("Utilitario");
                goToMain();
            }
        });
        btnOnibus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veiculo.setTipo("Onibus");
                goToMain();
            }
        });
        btnCaminhao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veiculo.setTipo("Caminhao");
                goToMain();
            }
        });
        btnCarreta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veiculo.setTipo("Carreta");
                goToMain();
            }
        });
        btnReboque.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                veiculo.setTipo("Reboque");
                goToMain();
            }
        });
        btnReturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =
                        new Intent(QualVeiculo.this, MainActivity.class);
                startActivity(intent);
                finish();
                return;
            }
        });
    }

    private void countVeiculos() {
        veiculos.add(veiculo);


        Log.i(AppUtil.LOG_APP, "#### DADOS VEICULOS ####");
        Log.i(AppUtil.LOG_APP, "VEICULO: "+veiculo.getTipo());
        Log.i(AppUtil.LOG_APP, "DE: "+veiculo.getEntrada());
        Log.i(AppUtil.LOG_APP, "PARA: "+veiculo.getSaida());
        Log.i(AppUtil.LOG_APP, "DATA: "+veiculo.getData());
        Log.i(AppUtil.LOG_APP, "HORA: "+veiculo.getHora());
        Log.i(AppUtil.LOG_APP, "#### -------------- ####");
        for (Veiculo veiculo:veiculos) {
            Log.i(AppUtil.LOG_APP, "Obj:"+veiculo.getTipo());
        }

    }

    private void goToMain() {
        countVeiculos();
        salvarSharedPreferences();
        Intent intent =
                new Intent(QualVeiculo.this, MainActivity.class);
        startActivity(intent);
        finish();
        return;
    }

    private void initFormulario() {
        btnReturn = findViewById(R.id.btnReturn);
        btnCarro = findViewById(R.id.btnCarro);
        btnMoto = findViewById(R.id.btnMoto);
        btnUtilitario = findViewById(R.id.btnUtilitario);
        btnOnibus = findViewById(R.id.btnOnibus);
        btnCaminhao = findViewById(R.id.btnCaminhao);
        btnCarreta = findViewById(R.id.btnCarreta);
        btnReboque = findViewById(R.id.btnReboque);

        fluxo = new FluxoVeiculo();
        veiculo = new Veiculo();
        veiculos = new ArrayList<>();
    }
    private void salvarSharedPreferences() {
        preferences = getSharedPreferences(AppUtil.PREF_APP, MODE_PRIVATE);
        SharedPreferences.Editor dados = preferences.edit();
        dados.putString("Veiculo", veiculo.getTipo());
        dados.apply();
    }

    private void restaurarSharedPreferences() {
        preferences = getSharedPreferences(AppUtil.PREF_APP, MODE_PRIVATE);
        veiculo.setEntrada(preferences.getString("Entrada", null));
        veiculo.setSaida(preferences.getString("Saída", null));
        veiculo.setData(preferences.getString("Data", null));
        veiculo.setHora(preferences.getString("Hora", null));

    }

}
