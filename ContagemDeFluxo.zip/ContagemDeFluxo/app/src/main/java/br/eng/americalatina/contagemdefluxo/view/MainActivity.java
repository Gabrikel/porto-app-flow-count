package br.eng.americalatina.contagemdefluxo.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import br.eng.americalatina.contagemdefluxo.R;
import br.eng.americalatina.contagemdefluxo.api.AppUtil;
import br.eng.americalatina.contagemdefluxo.model.FluxoVeiculo;
import br.eng.americalatina.contagemdefluxo.model.Veiculo;


public class MainActivity extends AppCompatActivity {
    private SharedPreferences preferences;

    public FluxoVeiculo fluxo;

    Button btn01, btn02, btn03, btn04;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        initFormulario();

        btn01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonWait(btn01);
            }
        });
        btn02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonWait(btn02);
            }
        });
        btn03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonWait(btn03);
            }
        });
        btn04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonWait(btn04);
            }
        });

    }

    private void initFormulario() {
        btn01 = findViewById(R.id.btn01);
        btn02 = findViewById(R.id.btn02);
        btn03 = findViewById(R.id.btn03);
        btn04 = findViewById(R.id.btn04);

        fluxo = new FluxoVeiculo();
    }

    private void goToChooseCar() {
        salvarSharedPreferences();
        Intent intent =
                new Intent(MainActivity.this, QualVeiculo.class);
        startActivity(intent);
        finish();
        return;
    }

    private void exitButton(){
        btn01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fluxo.setSaida("ES-162 - Sentido Pr. Kennedy");
                goToChooseCar();
            }
        });
        btn02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fluxo.setSaida("Acesso a Jaqueira");
                goToChooseCar();
            }
        });
        btn03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fluxo.setSaida("ES-060 - Sentido Marataizes");
                goToChooseCar();
            }
        });
        btn04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fluxo.setSaida("ES-060 - Sentido Praia das Neves");
                goToChooseCar();
            }
        });
    }

    /**
    <string name="btn01">ES-162 - Sentido Pr. Kennedy</string>
    <string name="btn02">Acesso à Jaqueira</string>
    <string name="btn03">Acesso à Jaqueira</string>
    <string name="btn04">ES-162 - Sentido Praia das Neves</string>

     */

    private void buttonWait(Button btnGeneric) {
        if (btnGeneric == btn01) {
            fluxo.setEntrada("ES-162 - Sentido Pr. Kennedy");
            fluxo.setData(AppUtil.getDataAtual());
            fluxo.setHora(AppUtil.getHoraAtual());
            exitButton();
        }
        if (btnGeneric == btn02) {
            fluxo.setEntrada("Acesso à Jaqueira");
            fluxo.setData(AppUtil.getDataAtual());
            fluxo.setHora(AppUtil.getHoraAtual());
            exitButton();
        }
        if (btnGeneric == btn03) {
            fluxo.setEntrada("ES-060 - Sentido Marataízes");
            fluxo.setData(AppUtil.getDataAtual());
            fluxo.setHora(AppUtil.getHoraAtual());
            exitButton();
        }
        if (btnGeneric == btn04) {
            fluxo.setEntrada("ES-060 - Sentido Praia das Neves");
            fluxo.setData(AppUtil.getDataAtual());
            fluxo.setHora(AppUtil.getHoraAtual());
            exitButton();
        }

    }
    private void salvarSharedPreferences() {
        preferences = getSharedPreferences(AppUtil.PREF_APP, MODE_PRIVATE);
        SharedPreferences.Editor dados = preferences.edit();
        dados.putString("Entrada", fluxo.getEntrada());
        dados.putString("Saída", fluxo.getSaida());
        dados.putString("Data", fluxo.getData());
        dados.putString("Hora", fluxo.getHora());
        dados.apply();
    }

    private void restaurarSharedPreferences() {
        preferences = getSharedPreferences(AppUtil.PREF_APP, MODE_PRIVATE);
        fluxo.setEntrada(preferences.getString("Entrada", null));
        fluxo.setSaida(preferences.getString("Saída", null));
        fluxo.setData(preferences.getString("Data", null));
        fluxo.setHora(preferences.getString("Hora", null));

    }

}