package br.eng.americalatina.contagemdefluxo.model;

public class FluxoController {



}
